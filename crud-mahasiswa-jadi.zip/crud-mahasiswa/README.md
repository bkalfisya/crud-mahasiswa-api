# CRUD Data Mahasiswa + API (proyek jadi)

Hasil akhir tutorial "Membuat API dengan PHP Murni", dipakai sebagai kunci jawaban.

1. Salin folder `crud-mahasiswa` ke `C:\xampp\htdocs\`.
2. Jalankan Apache dan MySQL dari XAMPP Control Panel.
3. Di phpMyAdmin, impor `database.sql`, lalu impor `bahan-tutorial/pengguna.sql`.
4. Buka:
   - Web biasa: `http://localhost/crud-mahasiswa/`
   - API: `http://localhost/crud-mahasiswa/api/`
   - Klien API: `http://localhost/crud-mahasiswa/klien-api.html`

Akun: admin / admin123 (boleh hapus), operator / operator123 (tidak boleh hapus).
Koleksi uji Postman: `bahan-tutorial/API-Data-Mahasiswa.postman_collection.json`.
Butuh PHP 8.1 atau lebih baru.
